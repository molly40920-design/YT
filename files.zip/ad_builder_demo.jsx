import React, { useState, useMemo } from "react";
import {
  Check, ChevronRight, Layers, Target, MapPin, LayoutGrid, Users,
  DollarSign, Image as ImageIcon, Sparkles, Settings, RotateCcw,
  Send, Eye, Zap, Info, Plus, X, Lock, Pencil, Copy, AlertTriangle,
} from "lucide-react";

/* ----------------------------- tokens ----------------------------- */
const BRAND = "#2E5A88";
const BRAND_DK = "#1F3D5C";
const SPLIT = "#B7791F";
const SPLIT_BG = "#FCEFCB";
const OK = "#0F766E";

/* ----------------------------- 連動規則 ----------------------------- */
/* 出價策略：鍵值 + 依 iOS14 切換顯示名稱 */
const BID = [
  { key: "max", off: "最高數量／消費金額", on: "最高數量" },
  { key: "cpa", off: "每次成果成本目標", on: "單次成效費用目標" },
  { key: "cap", off: "出價上限", on: "競價上限" },
  { key: "roas", off: "ROAS 目標", on: "廣告花費回報目標" },
];
const bidName = (key, ios14) => { const b = BID.find((x) => x.key === key); return ios14 ? b.on : b.off; };
const bidKeyFromName = (name) => { const b = BID.find((x) => x.on === name || x.off === name); return b ? b.key : "max"; };

const GOAL = { install: "應用安裝量最大化", event: "應用事件數量最大化", value: "轉化價值最大化", click: "鏈接點擊量最大化" };
function perfGoalOptions(ios14, bidKey) {
  if (!ios14) {
    if (bidKey === "max") return [GOAL.install, GOAL.event, GOAL.value, GOAL.click];
    if (bidKey === "cpa" || bidKey === "cap") return [GOAL.install, GOAL.event, GOAL.click];
    if (bidKey === "roas") return [GOAL.value];
  } else {
    if (bidKey === "max") return [GOAL.install, GOAL.event, GOAL.value];
    if (bidKey === "cpa" || bidKey === "cap") return [GOAL.install, GOAL.event];
    if (bidKey === "roas") return [GOAL.install, GOAL.value];
  }
  return [GOAL.install, GOAL.event];
}
function attributionOptions(ios14, goal) {
  if (goal === GOAL.click) return [];
  const install = goal === GOAL.install, ev = goal === GOAL.event || goal === GOAL.value;
  if (!ios14) {
    if (install) return ["點擊後 1 天內", "點擊後 1 天內，瀏覽後 1 天內"];
    if (ev) return ["點擊後 1 天內", "點擊後 7 天內"];
    return ["點擊後 1 天內"];
  } else {
    if (install) return ["點擊後 1 天內"];
    if (ev) return ["點擊後 1 天內", "點擊後 7 天內"];
    return ["點擊後 1 天內"];
  }
}

const STEPS = [
  { id: 1, t: "基礎設置", icon: Settings, stage: "Campaign" },
  { id: 2, t: "廣告系列", icon: Layers, stage: "Campaign" },
  { id: 3, t: "投放內容", icon: Target, stage: "Ad Set" },
  { id: 4, t: "地區組", icon: MapPin, stage: "Ad Set", module: "geo", cap: 30 },
  { id: 5, t: "版位", icon: LayoutGrid, stage: "Ad Set" },
  { id: 6, t: "定向包", icon: Users, stage: "Ad Set", module: "target", cap: 20 },
  { id: 7, t: "出價和預算", icon: DollarSign, stage: "Ad Set", module: "bid", cap: 20 },
  { id: 8, t: "創意設置", icon: ImageIcon, stage: "Ad" },
  { id: 9, t: "創意組", icon: Sparkles, stage: "Ad", module: "creative", cap: 30 },
];
const REGION_SUGGEST = ["亞洲 地區", "歐洲經濟區 (EEA)", "台灣", "香港", "新加坡", "馬來西亞", "日本", "Android 付費商店開放國家/地區"];
const mk = {
  geo: (n) => ({ name: `地區組${n}`, target: [], exclude: [] }),
  target: (n) => ({ name: `定向包${n}`, advantage: true, customAud: "不限", ageMin: "18", ageTo: "65+", gender: "不限", segment: "不限", lang: "", wifi: false }),
  bid: (n) => ({ name: `出價和預算${n}`, perfGoal: GOAL.install, adsetBidKey: "max", valueRule: "", eventDist: "統一分配", appEvent: "", attribution: "", schedule: "現在開始", startDate: new Date().toISOString().slice(0, 10), startTime: "", endDate: "", endTime: "", budget: "", targetControl: "", spendLow: "", spendHigh: "" }),
  creative: (n) => ({ name: `創意組${n}`, dynamic: false, creativeType: ["創建廣告"], format: ["單圖片或視頻"], destination: "應用", setupBy: "按創意組", optimize: "全面優化(全選)", deepLink: "", productPage: "", videoCount: 1, imageCount: 0, bodyTexts: [], titles: [], cta: "", tag: "", multiLang: false, coopAd: false, existingPost: "" }),
};

/* ----------------------------- 小元件 ----------------------------- */
const Hint = ({ children }) => <p className="mt-1 text-xs text-slate-500 leading-relaxed">{children}</p>;
const LinkBadge = ({ children }) => (
  <span className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] font-medium" style={{ background: "#EAF1F8", color: BRAND }}><Zap size={11} />{children}</span>
);
const SplitTag = ({ children }) => (
  <span className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] font-semibold" style={{ background: SPLIT_BG, color: SPLIT }}>{children}</span>
);
const FieldLabel = ({ children, req, badge }) => (
  <div className="flex items-center gap-2 mb-1.5 flex-wrap">
    <label className="text-sm font-semibold text-slate-700">{children}</label>
    {req && <span className="text-rose-500 text-xs">*</span>}{badge}
  </div>
);
const Toggle = ({ checked, onChange }) => (
  <button onClick={() => onChange(!checked)} className="relative inline-flex h-6 w-11 items-center rounded-full transition-colors shrink-0" style={{ background: checked ? BRAND : "#CBD5E1" }} aria-pressed={checked}>
    <span className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${checked ? "translate-x-5" : "translate-x-0.5"}`} />
  </button>
);
const Segmented = ({ options, value, onChange, disabled = [] }) => (
  <div className="inline-flex flex-wrap gap-1.5">
    {options.map((o) => {
      const dis = disabled.includes(o), active = value === o;
      return (
        <button key={o} disabled={dis} onClick={() => onChange(o)} className={`px-3 py-1.5 rounded-md text-sm border transition-all ${dis ? "opacity-40 cursor-not-allowed" : ""}`}
          style={{ borderColor: active ? BRAND : "#D8DEE7", background: active ? BRAND : "#fff", color: active ? "#fff" : "#475569", fontWeight: active ? 600 : 400 }}>
          {dis && <Lock size={11} className="inline mr-1 -mt-0.5" />}{o}
        </button>
      );
    })}
  </div>
);
const MultiSeg = ({ options, values, onToggle }) => (
  <div className="inline-flex flex-wrap gap-1.5">
    {options.map((o) => {
      const active = values.includes(o);
      return (
        <button key={o} onClick={() => onToggle(o)} className="px-3 py-1.5 rounded-md text-sm border transition-all relative overflow-hidden"
          style={{ borderColor: active ? BRAND : "#D8DEE7", background: active ? "#EAF1F8" : "#fff", color: active ? BRAND : "#475569", fontWeight: active ? 600 : 400 }}>
          {active && <span className="absolute top-0 right-0" style={{ width: 0, height: 0, borderTop: `9px solid ${BRAND}`, borderLeft: "9px solid transparent" }} />}
          {o}
        </button>
      );
    })}
  </div>
);
const Select = ({ options, value, onChange }) => (
  <select value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-300">
    {options.map((o) => <option key={o} value={o}>{o}</option>)}
  </select>
);
const Text = ({ value, onChange, placeholder }) => (
  <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-300" />
);
const Amount = ({ value, onChange, placeholder }) => (
  <div className="flex">
    <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="flex-1 rounded-l-md border border-slate-300 px-3 py-2 text-sm focus:outline-none" />
    <span className="rounded-r-md border border-l-0 border-slate-300 bg-slate-50 px-3 py-2 text-sm text-slate-500">USD</span>
  </div>
);
const Block = ({ children }) => <div className="mb-5">{children}</div>;
const Tokens = ({ list }) => (
  <div className="flex flex-wrap gap-1.5 mt-2">{list.map((t) => <span key={t} className="text-xs rounded border border-slate-200 px-2 py-0.5 text-slate-500">{t}</span>)}<span className="text-xs" style={{ color: BRAND }}>展開</span></div>
);
function Counter({ value, onChange, label }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-slate-600 w-12">{label}</span>
      <button onClick={() => onChange(Math.max(0, value - 1))} className="h-8 w-8 rounded-md border border-slate-300 text-slate-600">−</button>
      <span className="w-8 text-center text-sm font-semibold" style={{ color: SPLIT }}>{value}</span>
      <button onClick={() => onChange(value + 1)} className="h-8 w-8 rounded-md border border-slate-300 text-slate-600">＋</button>
    </div>
  );
}
function TagAdder({ items, onAdd, onRemove, placeholder, suggestions = [], tone = SPLIT }) {
  const [v, setV] = useState("");
  const add = (val) => { const x = (val ?? v).trim(); if (x) { onAdd(x); setV(""); } };
  const bg = tone === SPLIT ? SPLIT_BG : tone === BRAND ? "#EAF1F8" : "#FEE2E2";
  return (
    <div>
      <div className="flex gap-2">
        <input value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} placeholder={placeholder} className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-300" />
        <button onClick={() => add()} className="rounded-md px-3 text-white text-sm flex items-center gap-1" style={{ background: BRAND }}><Plus size={14} />新增</button>
      </div>
      {suggestions.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-2">{suggestions.filter((x) => !items.includes(x)).map((x) => (
          <button key={x} onClick={() => add(x)} className="text-xs rounded-full border border-slate-200 px-2 py-0.5 text-slate-500 hover:border-slate-400">+ {x}</button>
        ))}</div>
      )}
      {items.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-2">{items.map((it, i) => (
          <span key={i} className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium" style={{ background: bg, color: tone }}>
            {it}<button onClick={() => onRemove(i)}><X size={12} /></button>
          </span>
        ))}</div>
      )}
    </div>
  );
}
function ModuleTabs({ groups, active, onSelect, onAdd, onRemove, cap }) {
  return (
    <div className="flex items-center justify-between border-b border-slate-200 mb-4">
      <div className="flex items-end gap-1 flex-wrap">
        {groups.map((g, i) => {
          const on = i === active;
          return (
            <button key={i} onClick={() => onSelect(i)} className="group flex items-center gap-1.5 px-3 py-2 text-sm rounded-t-md border-b-2 -mb-px" style={{ borderColor: on ? BRAND : "transparent", color: on ? BRAND : "#64748B", background: on ? "#F5F8FC" : "transparent", fontWeight: on ? 600 : 400 }}>
              {g.name}
              {groups.length > 1 && <span onClick={(e) => { e.stopPropagation(); onRemove(i); }} className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-rose-500"><X size={12} /></span>}
            </button>
          );
        })}
      </div>
      <div className="flex items-center gap-3 pb-2">
        <button onClick={onAdd} disabled={groups.length >= cap} className="flex items-center gap-1 text-sm disabled:opacity-40" style={{ color: BRAND }}><Plus size={14} />新增</button>
        <span className="text-xs text-slate-400">{groups.length}/{cap}</span>
      </div>
    </div>
  );
}

/* ----------------------------- 主元件 ----------------------------- */
export default function AdBuilderDemo() {
  const [step, setStep] = useState(2);
  const [toast, setToast] = useState("");
  const [preview, setPreview] = useState(false);
  const [rowStatus, setRowStatus] = useState({});
  const init = {
    platform: "META", objective: "應用程式推廣", adAccount: "act_金好運TW",
    campaignName: "{賬戶名}_{賬戶備註名}", campaignStatus: true, specialCategory: "請選擇",
    ios14: true, cbo: true,
    budgetType: "單日預算", campaignBudget: "", campaignBidKey: "max", deliveryType: "標準", campaignSpendCap: "不限",
    store: "App Store", appName: "金好運娛樂城", adsetName: "{賬戶備註名}_{地區組名稱}_{系統用戶名}", adsetStatus: true,
    placement: "Advantage+ 版位（全平台）",
    platforms: { Facebook: true, Instagram: true, Messenger: true, "Audience Network": true, Threads: true },
    adName: "{首個素材名稱}_{首個素材名稱（含格式）}", adStatus: false, fbPage: "", pageType: "全部主頁", usePublicPage: false, multiAdvertiser: true, websiteEvent: "",
    geo: [mk.geo(1), mk.geo(2)], target: [mk.target(1)], bid: [mk.bid(1)], creative: [mk.creative(1)],
  };
  const [s, setS] = useState(init);
  const [act, setAct] = useState({ geo: 0, target: 0, bid: 0, creative: 0 });
  const set = (patch) => setS((p) => ({ ...p, ...patch }));
  const addGroup = (key) => setS((p) => {
    const cap = STEPS.find((x) => x.module === key).cap;
    if (p[key].length >= cap) return p;
    const arr = [...p[key], mk[key](p[key].length + 1)];
    setAct((a) => ({ ...a, [key]: arr.length - 1 })); return { ...p, [key]: arr };
  });
  const removeGroup = (key, i) => setS((p) => {
    if (p[key].length <= 1) return p;
    const arr = p[key].filter((_, x) => x !== i);
    setAct((a) => ({ ...a, [key]: Math.min(a[key], arr.length - 1) })); return { ...p, [key]: arr };
  });
  const patchGroup = (key, i, patch) => setS((p) => ({ ...p, [key]: p[key].map((g, x) => x === i ? { ...g, ...patch } : g) }));

  const svMaterial = (g) => Math.max(g.videoCount + g.imageCount, 1);
  const adsOf = (g) => {
    const bodyN = Math.max(g.bodyTexts.length, 1);
    let ads = 0;
    if (g.creativeType.includes("創建廣告")) g.format.forEach((f) => {
      const titleN = f === "單圖片或視頻" ? Math.max(g.titles.length, 1) : 1;
      ads += (f === "單圖片或視頻" ? svMaterial(g) : 1) * bodyN * titleN;
    });
    if (g.creativeType.includes("使用已有帖子")) ads += 1;
    return Math.max(ads, 1);
  };
  const m = useMemo(() => {
    const R = s.geo.length, T = s.target.length, B = s.bid.length, C = s.creative.length;
    const adSets = R * T * B * C;
    const ads = R * T * B * s.creative.reduce((acc, g) => acc + adsOf(g), 0);
    return { R, T, B, C, adSets, ads };
  }, [s.geo, s.target, s.bid, s.creative]);

  /* ---------------- 模組表單 ---------------- */
  function geoForm(g, i) {
    const eu = g.target.some((r) => ["歐洲經濟區 (EEA)", "台灣", "新加坡", "澳洲", "印度"].includes(r));
    return (<>
      <div className="text-sm text-slate-600 mb-2 flex items-center gap-2">綁定對象 <span className="text-slate-400">地區（全部）</span><Pencil size={13} className="text-slate-400" /></div>
      <button className="text-sm mb-4 flex items-center gap-1.5" style={{ color: BRAND }}><Copy size={13} />選擇已有地區組</button>
      <Block><FieldLabel req>地區</FieldLabel>
        <div className="grid grid-cols-2 gap-3">
          <div><div className="text-xs text-slate-500 mb-1">名稱（點擊加入定向）</div>
            <TagAdder items={g.target} tone={BRAND} onAdd={(v) => patchGroup("geo", i, { target: [...g.target, v] })} onRemove={(x) => patchGroup("geo", i, { target: g.target.filter((_, y) => y !== x) })} placeholder="搜尋國家／地區" suggestions={REGION_SUGGEST} /></div>
          <div><div className="text-xs text-slate-500 mb-1">已選 · 定向({g.target.length}) / 排除({g.exclude.length})</div>
            <TagAdder items={g.exclude} tone={"#B91C1C"} onAdd={(v) => patchGroup("geo", i, { exclude: [...g.exclude, v] })} onRemove={(x) => patchGroup("geo", i, { exclude: g.exclude.filter((_, y) => y !== x) })} placeholder="加入排除地區" /></div>
        </div>
      </Block>
      {eu && (<div className="rounded-md border-l-4 pl-4 py-3" style={{ borderColor: BRAND, background: "#F5F8FC" }}>
        <div className="text-xs mb-2" style={{ color: BRAND }}>定位歐盟／台灣等地區時，需指明受益方與贊助方。</div>
        <Block><FieldLabel>在什麼地區投放金融產品和服務類廣告</FieldLabel><Select options={["不勾選（固定）"]} value="不勾選（固定）" onChange={() => {}} /></Block>
        <Block><FieldLabel badge={<LinkBadge>因含台灣／歐盟</LinkBadge>}>受益方（台灣地區）</FieldLabel><Select options={["IGS 鈊象電子股份有限公司"]} value="IGS 鈊象電子股份有限公司" onChange={() => {}} /></Block>
        <div><FieldLabel>贊助方（台灣地區）</FieldLabel><Select options={["關閉（固定）"]} value="關閉（固定）" onChange={() => {}} /></div>
      </div>)}
    </>);
  }
  function targetForm(g, i) {
    return (<>
      <div className="text-sm text-slate-600 mb-3 flex items-center gap-2">綁定對象 <span className="text-slate-400">地區（全部）</span><Pencil size={13} className="text-slate-400" /></div>
      <Block><div className="flex items-center justify-between"><FieldLabel>進階賦能型受眾</FieldLabel><Toggle checked={g.advantage} onChange={(v) => patchGroup("target", i, { advantage: v })} /></div></Block>
      <Block><FieldLabel req>自訂受眾</FieldLabel><Segmented options={["不限", "自訂"]} value={g.customAud} onChange={(v) => patchGroup("target", i, { customAud: v })} /></Block>
      <div className="grid grid-cols-2 gap-3">
        <Block><FieldLabel req>最低年齡限制</FieldLabel><Select options={["18", "20", "21", "25"]} value={g.ageMin} onChange={(v) => patchGroup("target", i, { ageMin: v })} /></Block>
        <Block><FieldLabel>年齡建議</FieldLabel><div className="flex items-center gap-2"><Select options={["18", "20", "25"]} value={g.ageMin} onChange={() => {}} /><span className="text-slate-400">~</span><Select options={["65+", "45", "55"]} value={g.ageTo} onChange={(v) => patchGroup("target", i, { ageTo: v })} /></div></Block>
      </div>
      <Block><FieldLabel>性別</FieldLabel><Segmented options={["不限", "男性", "女性"]} value={g.gender} onChange={(v) => patchGroup("target", i, { gender: v })} /></Block>
      <Block><FieldLabel>細分定位</FieldLabel><Segmented options={["不限", "自訂"]} value={g.segment} onChange={(v) => patchGroup("target", i, { segment: v })} /></Block>
      <Block><FieldLabel>語言</FieldLabel><Select options={["請選擇", "繁體中文", "English", "所有語言"]} value={g.lang || "請選擇"} onChange={(v) => patchGroup("target", i, { lang: v })} /></Block>
      <Block><FieldLabel req>操作系統版本</FieldLabel><Hint>依步驟 3 商店（{s.store === "App Store" ? "iOS" : "Android"}）給出版本選單。</Hint></Block>
      <div><div className="flex items-center justify-between"><FieldLabel>只在連線到 Wi-Fi 時</FieldLabel><Toggle checked={g.wifi} onChange={(v) => patchGroup("target", i, { wifi: v })} /></div></div>
    </>);
  }
  function bidForm(g, i) {
    const bidKey = s.cbo ? s.campaignBidKey : g.adsetBidKey;
    const goalOpts = perfGoalOptions(s.ios14, bidKey);
    const goal = goalOpts.includes(g.perfGoal) ? g.perfGoal : "";
    const attrOpts = attributionOptions(s.ios14, goal);
    const needTC = ["roas", "cpa", "cap"].includes(bidKey);
    const showValueRule = bidKey === "max" && [GOAL.install, GOAL.event, GOAL.click].includes(goal);
    return (<>
      <div className="text-sm text-slate-600 mb-3 flex items-center gap-2">綁定對象 <span className="text-slate-400">地區（全部）</span><Pencil size={13} className="text-slate-400" /></div>
      <Block><FieldLabel req badge={<LinkBadge>受出價策略「{bidName(bidKey, s.ios14)}」連動</LinkBadge>}>成效目標</FieldLabel>
        <Segmented options={goalOpts} value={goal} onChange={(v) => patchGroup("bid", i, { perfGoal: v })} />
        <Hint>可選項依 iOS 14+（{s.ios14 ? "開" : "關"}）與出價策略動態變化。</Hint></Block>
      {!s.cbo && (<Block><FieldLabel req badge={<LinkBadge>因 CBO 關閉</LinkBadge>}>出價策略</FieldLabel>
        <Select options={BID.map((b) => bidName(b.key, s.ios14))} value={bidName(g.adsetBidKey, s.ios14)} onChange={(v) => patchGroup("bid", i, { adsetBidKey: bidKeyFromName(v) })} />
        <Hint>每個出價組合獨立決定。</Hint></Block>)}
      {s.cbo && (<div className="text-xs rounded-md p-2.5 mb-4" style={{ background: "#F5F8FC", color: BRAND }}>CBO 已開啟：出價策略「{bidName(s.campaignBidKey, s.ios14)}」與預算設於步驟 2（Campaign 層），此處不重複。</div>)}
      {showValueRule && (<Block><FieldLabel badge={<LinkBadge>條件符合</LinkBadge>}>價值規則集</FieldLabel><Select options={["請選擇", "規則集 A", "規則集 B"]} value={g.valueRule || "請選擇"} onChange={(v) => patchGroup("bid", i, { valueRule: v })} /></Block>)}
      {goal === GOAL.event && (<>
        <Block><FieldLabel badge={<LinkBadge>因成效目標＝應用事件</LinkBadge>}>應用事件分配方式</FieldLabel><Segmented options={["統一分配", "按賬戶"]} value={g.eventDist} onChange={(v) => patchGroup("bid", i, { eventDist: v })} /></Block>
        <Block><FieldLabel req badge={<LinkBadge>因成效目標＝應用事件</LinkBadge>}>應用事件</FieldLabel><Select options={["請選擇推廣應用", "完成註冊", "加入購物車", "完成購買", "完成教學"]} value={g.appEvent || "請選擇推廣應用"} onChange={(v) => patchGroup("bid", i, { appEvent: v === "請選擇推廣應用" ? "" : v })} /></Block>
      </>)}
      {goal === GOAL.value && (<Block><FieldLabel req badge={<LinkBadge>因成效目標＝轉化價值</LinkBadge>}>轉化事件</FieldLabel><Select options={["購物"]} value="購物" onChange={() => {}} /><Hint>固定為「購物」。</Hint></Block>)}
      {needTC && (<Block><FieldLabel req badge={<LinkBadge>因出價策略＝{bidName(bidKey, s.ios14)}</LinkBadge>}>目標控制金額</FieldLabel><Amount value={g.targetControl} onChange={(v) => patchGroup("bid", i, { targetControl: v })} placeholder={bidKey === "roas" ? "預設 0.01" : "預設 2"} /></Block>)}
      {s.ios14 && <Block><FieldLabel badge={<LinkBadge>因 iOS 14+ 開啟</LinkBadge>}>廣告歸因方法</FieldLabel><Select options={["全事件衡量"]} value="全事件衡量" onChange={() => {}} /></Block>}
      {attrOpts.length > 0 ? (<Block><FieldLabel req>歸因設置</FieldLabel><Select options={attrOpts} value={attrOpts.includes(g.attribution) ? g.attribution : attrOpts[0]} onChange={(v) => patchGroup("bid", i, { attribution: v })} /></Block>) : <div className="text-xs text-slate-400 italic mb-4">＊成效目標為「鏈接點擊量最大化」時，歸因設置不出現。</div>}
      <Block><FieldLabel>計費方式</FieldLabel><Segmented options={["展示次數"]} value="展示次數" onChange={() => {}} /></Block>
      <Block><FieldLabel>排期</FieldLabel><Segmented options={["現在開始", "自訂"]} value={g.schedule} onChange={(v) => patchGroup("bid", i, { schedule: v })} />
        {g.schedule === "自訂" && (<div className="mt-3 space-y-3 rounded-lg p-3" style={{ background: "#F5F8FC" }}>
          <div><div className="text-xs font-semibold text-slate-600 mb-1 flex items-center gap-2">開始時間 <span className="text-rose-500">*</span><LinkBadge>因排期＝自訂</LinkBadge></div>
            <div className="flex items-center gap-2 flex-wrap">
              <input type="date" value={g.startDate} onChange={(e) => patchGroup("bid", i, { startDate: e.target.value })} className="rounded-md border border-slate-300 px-2 py-1.5 text-sm text-slate-700" />
              <input type="time" value={g.startTime} onChange={(e) => patchGroup("bid", i, { startTime: e.target.value })} className="rounded-md border border-slate-300 px-2 py-1.5 text-sm text-slate-700" />
              <span className="text-xs text-slate-400">Asia/Taipei</span>
            </div></div>
          <div><div className="text-xs font-semibold text-slate-600 mb-1">結束時間</div>
            <div className="flex items-center gap-2 flex-wrap">
              <input type="date" value={g.endDate} onChange={(e) => patchGroup("bid", i, { endDate: e.target.value })} className="rounded-md border border-slate-300 px-2 py-1.5 text-sm text-slate-700" />
              <input type="time" value={g.endTime} onChange={(e) => patchGroup("bid", i, { endTime: e.target.value })} className="rounded-md border border-slate-300 px-2 py-1.5 text-sm text-slate-700" />
              <span className="text-xs text-slate-400">Asia/Taipei</span>
            </div></div>
        </div>)}
      </Block>
      {!s.cbo
        ? <Block><FieldLabel req badge={<LinkBadge>因 CBO 關閉</LinkBadge>}>廣告組預算（單日）</FieldLabel><Amount value={g.budget} onChange={(v) => patchGroup("bid", i, { budget: v })} placeholder="輸入單日預算金額" /></Block>
        : <div><FieldLabel badge={<LinkBadge>因 CBO 開啟</LinkBadge>}>廣告組花費限額</FieldLabel><div className="flex items-center gap-2">
            <Amount value={g.spendLow} onChange={(v) => patchGroup("bid", i, { spendLow: v })} placeholder="下限" /><span className="text-xs text-slate-400">~</span>
            <Amount value={g.spendHigh} onChange={(v) => patchGroup("bid", i, { spendHigh: v })} placeholder="上限" /></div></div>}
    </>);
  }
  function creativeForm(g, i) {
    const cset = (patch) => patchGroup("creative", i, patch);
    const ct = g.creativeType, fmts = g.format;
    const isCreate = ct.includes("創建廣告");
    const isPost = ct.includes("使用已有帖子");
    const hasFmt = fmts.length > 0;
    const showFlex = isCreate && fmts.includes("靈活");
    const showSV = isCreate && fmts.includes("單圖片或視頻");
    const showCarousel = isCreate && fmts.includes("輪播");
    const showTargetSetup = isCreate && showSV;
    const toggleArr = (key, v) => { const a = g[key]; cset({ [key]: a.includes(v) ? a.filter((x) => x !== v) : [...a, v] }); };
    const ads = adsOf(g);
    const DeepLink = (<Block><FieldLabel>延遲深度連結</FieldLabel><Text value={g.deepLink} onChange={(v) => cset({ deepLink: v })} placeholder="請輸入" />
      <div className="flex flex-wrap gap-1.5 mt-2">{["廣告系列名稱", "廣告組名稱", "廣告名稱"].map((t) => <span key={t} className="text-xs rounded border border-slate-200 px-2 py-0.5 text-slate-400">{t}</span>)}</div></Block>);
    const ProductPage = (<Block><FieldLabel>自定義商品頁面</FieldLabel><Text value={g.productPage} onChange={(v) => cset({ productPage: v })} placeholder="請輸入自定義商品頁面 ID" /></Block>);
    const Optimize = (label) => (<Block><div className="text-xs text-slate-600 mb-1 leading-tight">使用進階賦能型素材{label}</div><Select options={["全面優化(全選)", "部分優化", "不優化"]} value={g.optimize} onChange={(v) => cset({ optimize: v })} /></Block>);
    const UploadBtn = (label) => (<button className="rounded-md border border-slate-300 px-3 py-1.5 text-sm text-slate-600 flex items-center gap-1.5"><ImageIcon size={14} />{label}</button>);
    const CopyField = (key, label, opt = false) => {
      const items = g[key], n = Math.max(items.length, 1);
      return (<Block>
        <FieldLabel req={!opt} badge={<SplitTag>{label} ×{n}</SplitTag>}>{label}</FieldLabel>
        <div className="flex items-center gap-2 mb-1.5"><button className="rounded-md border border-slate-300 px-2.5 py-1 text-xs text-slate-600">選文案</button><button className="rounded-md border border-slate-300 px-2.5 py-1 text-xs text-slate-600">批量添加文案</button><span className="text-xs text-slate-400">({items.length}/5)</span></div>
        <TagAdder items={items} onAdd={(v) => items.length < 5 && cset({ [key]: [...items, v] })} onRemove={(x) => cset({ [key]: items.filter((_, y) => y !== x) })} placeholder={`請輸入${label}`} />
      </Block>);
    };
    return (<>
      <div className="rounded-md px-3 py-2 mb-3 text-xs flex items-center gap-1.5" style={{ background: "#EAF1F8", color: BRAND }}><Info size={13} />視頻、圖片、輪播、單個主頁的帖子、靈活格式創意共最多上傳 50 個，輪播多個素材也僅占用一個額度。本組目前產生 {ads} 則廣告。</div>
      <div className="text-sm text-slate-600 mb-2 flex items-center gap-2">綁定對象 <span className="text-slate-400">地區（全部）</span><Pencil size={13} className="text-slate-400" /></div>
      <button className="text-sm mb-4 flex items-center gap-1.5" style={{ color: BRAND }}><Copy size={13} />選擇已有創意組</button>
      <Block><div className="flex items-center justify-between"><FieldLabel>動態素材</FieldLabel><Toggle checked={g.dynamic} onChange={(v) => cset({ dynamic: v })} /></div></Block>
      <Block><FieldLabel req>創意類型</FieldLabel><MultiSeg options={["創建廣告", "使用已有帖子"]} values={g.creativeType} onToggle={(v) => toggleArr("creativeType", v)} /><Hint>可複選；選定的類型與格式會各自生成廣告並加總。</Hint></Block>

      {isCreate && (<>
        <Block><FieldLabel req>格式</FieldLabel><MultiSeg options={["靈活", "單圖片或視頻", "輪播"]} values={g.format} onToggle={(v) => toggleArr("format", v)} />
          {!hasFmt && <div className="text-xs text-rose-500 mt-1">請選擇格式</div>}</Block>

        {showFlex && (<>
          <Block><FieldLabel req>靈活格式創意</FieldLabel>{UploadBtn("批量添加素材")}<button className="block text-sm mt-2" style={{ color: BRAND }}>添加分組</button></Block>
          {Optimize("優化靈活格式創意")}
        </>)}

        {showTargetSetup && (<>
          <Block><FieldLabel>添加目標位置</FieldLabel><Segmented options={["應用", "試玩廣告來源"]} value={g.destination} onChange={(v) => cset({ destination: v })} /></Block>
          <Block><FieldLabel>設置方式</FieldLabel><Segmented options={["按創意組", "按素材"]} value={g.setupBy} onChange={(v) => cset({ setupBy: v })} /></Block>
        </>)}

        {(<>{DeepLink}{ProductPage}</>)}

        {showSV && (<>
          <Block><FieldLabel req badge={<SplitTag>視頻 ×{g.videoCount}</SplitTag>}>視頻</FieldLabel>
            <div className="flex items-center gap-3">{UploadBtn("添加素材")}<Counter label="" value={g.videoCount} onChange={(v) => cset({ videoCount: v })} /></div></Block>
          {Optimize("優化視頻廣告")}
          <Block><FieldLabel req badge={<SplitTag>圖片 ×{g.imageCount}</SplitTag>}>圖片</FieldLabel>
            <div className="flex items-center gap-3">{UploadBtn("添加素材")}<Counter label="" value={g.imageCount} onChange={(v) => cset({ imageCount: v })} /></div></Block>
          {Optimize("優化圖片廣告")}
          <div className="text-xs mb-3" style={{ color: SPLIT }}>＊單圖片或視頻 素材拆分基數 = 視頻 + 圖片 = {svMaterial(g)}</div>
          <Block><div className="flex items-center justify-between"><FieldLabel badge={<LinkBadge>僅此格式</LinkBadge>}>多語言</FieldLabel><Toggle checked={g.multiLang} onChange={(v) => cset({ multiLang: v })} /></div></Block>
        </>)}

        {showCarousel && (<>
          <Block><FieldLabel req>輪播</FieldLabel>{UploadBtn("添加素材")}<Hint>多卡片組成 1 則廣告，不依素材數拆分。</Hint></Block>
          {Optimize("優化輪播廣告")}
        </>)}

        {CopyField("bodyTexts", "正文")}
        {showSV && CopyField("titles", "標題", true)}
        <Block><FieldLabel req>行動號召</FieldLabel><Select options={["請選擇", "立即安裝", "立即使用", "立即下載", "立即玩", "立即觀看", "了解詳情", "註冊", "開始使用"]} value={g.cta || "請選擇"} onChange={(v) => cset({ cta: v === "請選擇" ? "" : v })} /></Block>
      </>)}
      {isPost && (<>
        <Block><div className="flex items-center justify-between"><FieldLabel badge={<LinkBadge>因「使用已有帖子」</LinkBadge>}>合創廣告</FieldLabel><Toggle checked={g.coopAd} onChange={(v) => cset({ coopAd: v })} /></div></Block>
        {!g.coopAd && <Block><FieldLabel req>帖子</FieldLabel><Select options={["請選擇 Facebook 公共主頁", "貼文 #2025-06-01", "貼文 #2025-05-20"]} value={g.existingPost || "請選擇 Facebook 公共主頁"} onChange={(v) => cset({ existingPost: v })} /><Hint>文案／標題隨原貼文，隱藏素材上傳區。</Hint></Block>}
      </>)}

      <Block><FieldLabel>標籤</FieldLabel><Select options={["請選擇", "標籤 A", "標籤 B"]} value={g.tag || "請選擇"} onChange={(v) => cset({ tag: v === "請選擇" ? "" : v })} /></Block>
      <Block><FieldLabel req>創意組名稱</FieldLabel>
        <div className="relative"><input value={g.name} maxLength={100} onChange={(e) => cset({ name: e.target.value })} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-300" />
          <span className="absolute right-3 top-2.5 text-xs text-slate-400">{g.name.length}/100</span></div></Block>
    </>);
  }

  function renderStep() {
    const stp = STEPS.find((x) => x.id === step);
    if (stp.module) {
      const key = stp.module, groups = s[key], i = Math.min(act[key], groups.length - 1), g = groups[i];
      const forms = { geo: geoForm, target: targetForm, bid: bidForm, creative: creativeForm };
      return (<><ModuleTabs groups={groups} active={i} cap={stp.cap} onSelect={(x) => setAct((a) => ({ ...a, [key]: x }))} onAdd={() => addGroup(key)} onRemove={(x) => removeGroup(key, x)} />{forms[key](g, i)}</>);
    }
    switch (step) {
      case 1: return (<>
        <Block><FieldLabel req>投放平台</FieldLabel><Segmented options={["META", "Google", "TikTok", "ASA", "Applovin"]} value={s.platform} onChange={(v) => set({ platform: v })} disabled={["Google", "TikTok", "ASA", "Applovin"]} /><Hint>第一階段僅實作 META。</Hint></Block>
        <Block><FieldLabel req>行銷活動目標</FieldLabel><Select options={["應用程式推廣"]} value={s.objective} onChange={(v) => set({ objective: v })} /></Block>
        <Block><FieldLabel req>廣告帳戶</FieldLabel><Select options={["act_金好運TW", "act_金猴爺"]} value={s.adAccount} onChange={(v) => set({ adAccount: v })} /></Block>
      </>);
      case 2: {
        const bidKey = s.campaignBidKey;
        return (<>
          <Block><FieldLabel req>廣告系列名稱</FieldLabel><Text value={s.campaignName} onChange={(v) => set({ campaignName: v })} /></Block>
          <Block><div className="flex items-center justify-between"><FieldLabel>廣告系列狀態</FieldLabel><Toggle checked={s.campaignStatus} onChange={(v) => set({ campaignStatus: v })} /></div></Block>
          <Block><FieldLabel>特殊廣告類別</FieldLabel><Select options={["請選擇", "信貸", "就業", "住房", "社會議題／選舉／政治"]} value={s.specialCategory} onChange={(v) => set({ specialCategory: v })} /></Block>
          <Block><div className="flex items-center justify-between"><FieldLabel>iOS 14+ 廣告系列</FieldLabel><Toggle checked={s.ios14} onChange={(v) => set({ ios14: v, store: v ? "App Store" : s.store })} /></div><Hint>關鍵連動：影響商店、成效目標、歸因，並改變出價策略的顯示名稱。</Hint></Block>
          <Block><div className="flex items-center justify-between"><FieldLabel>賦能型廣告系列預算優化（CBO）</FieldLabel><Toggle checked={s.cbo} onChange={(v) => set({ cbo: v })} /></div><Hint>開啟→預算與出價設於此（Campaign 層）；關閉→設於每個出價組合（步驟 7）。</Hint></Block>
          {s.cbo && (<div className="rounded-lg border-l-4 pl-4 py-3" style={{ borderColor: BRAND, background: "#F5F8FC" }}>
            <Block><FieldLabel req badge={<LinkBadge>因 CBO 開啟</LinkBadge>}>廣告系列預算</FieldLabel>
              <Segmented options={["單日預算", "總預算"]} value={s.budgetType} onChange={(v) => set({ budgetType: v })} />
              <div className="mt-2"><Amount value={s.campaignBudget} onChange={(v) => set({ campaignBudget: v })} placeholder="請輸入" /></div></Block>
            <Block><FieldLabel req badge={s.ios14 ? <LinkBadge>iOS 14+ 名稱</LinkBadge> : null}>廣告系列競價策略</FieldLabel>
              <Segmented options={BID.map((b) => bidName(b.key, s.ios14))} value={bidName(bidKey, s.ios14)} onChange={(v) => set({ campaignBidKey: bidKeyFromName(v) })} /></Block>
            <Block><FieldLabel>投放時段</FieldLabel><Segmented options={["全天投放廣告"]} value="全天投放廣告" onChange={() => {}} /></Block>
            <Block><FieldLabel badge={bidKey === "cap" ? <LinkBadge>因競價上限</LinkBadge> : null}>投放類型</FieldLabel>
              {bidKey === "cap" ? <Segmented options={["標準", "快速"]} value={s.deliveryType} onChange={(v) => set({ deliveryType: v })} /> : <Segmented options={["勻速"]} value="勻速" onChange={() => {}} />}</Block>
            <Block><FieldLabel>廣告系列花費限額</FieldLabel><Segmented options={["不限", "自訂"]} value={s.campaignSpendCap} onChange={(v) => set({ campaignSpendCap: v })} />
              {s.campaignSpendCap === "自訂" && <div className="mt-2"><Amount value="" onChange={() => {}} placeholder="花費上限金額" /></div>}</Block>
            <div className="flex items-start gap-1.5 text-xs" style={{ color: SPLIT }}><AlertTriangle size={13} className="mt-0.5 shrink-0" />花費限額不是預算；如需設置廣告系列預算，請開啟 CBO。</div>
          </div>)}
        </>);
      }
      case 3: return (<>
        <Block><FieldLabel req>廣告組名稱</FieldLabel><Text value={s.adsetName} onChange={(v) => set({ adsetName: v })} /></Block>
        <Block><div className="flex items-center justify-between"><FieldLabel>廣告組狀態</FieldLabel><Toggle checked={s.adsetStatus} onChange={(v) => set({ adsetStatus: v })} /></div></Block>
        <Block><FieldLabel req badge={s.ios14 ? <LinkBadge>因 iOS 14+ 鎖 App Store</LinkBadge> : null}>移動應用商店</FieldLabel>
          {s.ios14
            ? <Segmented options={["App Store"]} value="App Store" onChange={() => {}} />
            : <Segmented options={["Google Play", "App Store", "Samsung Galaxy Store", "亞馬遜應用商店", "小遊戲"]} value={s.store} onChange={(v) => set({ store: v })} />}
        </Block>
        <Block><FieldLabel req>應用</FieldLabel>
          <div className="flex items-center justify-between rounded-md border border-slate-300 px-3 py-2" style={{ maxWidth: 360 }}>
            <div className="flex items-center gap-2.5">
              <div className="h-8 w-8 rounded bg-slate-100 flex items-center justify-center text-slate-400 text-xs">App</div>
              <div><div className="text-sm text-slate-700">{s.appName || "金好運娛樂城"}</div><div className="text-xs text-slate-400">242649556152905</div></div>
            </div>
            <span className="text-xs text-slate-400">{s.store === "App Store" ? "iOS ▾" : "Android ▾"}</span>
          </div></Block>
        <Hint>商店與 App 為行銷活動共用設定；成效目標／歸因移至「出價和預算」步驟。</Hint>
      </>);
      case 5: return (<>
        <Block><FieldLabel>版位設置</FieldLabel><Segmented options={["Advantage+ 版位（全平台）", "手動編輯"]} value={s.placement} onChange={(v) => set({ placement: v })} /></Block>
        {s.placement === "手動編輯" && (<Block><FieldLabel badge={<LinkBadge>因「手動編輯」</LinkBadge>}>平台與版位</FieldLabel>
          <div className="flex flex-wrap gap-2">{Object.keys(s.platforms).map((pf) => (
            <button key={pf} onClick={() => set({ platforms: { ...s.platforms, [pf]: !s.platforms[pf] } })} className="px-3 py-1.5 rounded-md text-sm border flex items-center gap-1.5" style={{ borderColor: s.platforms[pf] ? BRAND : "#D8DEE7", background: s.platforms[pf] ? "#EAF1F8" : "#fff", color: s.platforms[pf] ? BRAND : "#94A3B8" }}>{s.platforms[pf] && <Check size={13} />}{pf}</button>
          ))}</div><Hint>含 Threads，可取消勾選。</Hint></Block>)}
      </>);
      case 8: return (<>
        <Block><FieldLabel req>廣告名稱</FieldLabel><Text value={s.adName} onChange={(v) => set({ adName: v })} /></Block>
        <Block><div className="flex items-center justify-between"><FieldLabel>廣告狀態</FieldLabel><Toggle checked={s.adStatus} onChange={(v) => set({ adStatus: v })} /></div></Block>
        <div className="flex items-start gap-1.5 mb-4 text-xs rounded-md p-2.5" style={{ background: "#FFF7ED", color: SPLIT }}>
          <AlertTriangle size={13} className="mt-0.5 shrink-0" />若您的主頁沒有全部授權，可能導致無法找到所需主頁，建議授權現有和今後的所有主頁。
        </div>
        <Block><FieldLabel>主頁類型</FieldLabel><Segmented options={["全部主頁", "個人號主頁", "廣告賬戶主頁"]} value={s.pageType} onChange={(v) => set({ pageType: v })} /></Block>
        <Block><FieldLabel req>Facebook 公共主頁</FieldLabel>
          <div className="flex items-center gap-2">
            <div className="flex-1"><Select options={["請選擇", "金好運官方", "金猴爺娛樂城"]} value={s.fbPage || "請選擇"} onChange={(v) => set({ fbPage: v === "請選擇" ? "" : v })} /></div>
            <button className="text-sm whitespace-nowrap" style={{ color: BRAND }}>找不到主頁?</button>
          </div></Block>
        <Block><div className="flex items-center justify-between gap-3"><FieldLabel>使用公共主頁而不是應用名稱作為廣告發布身份</FieldLabel><Toggle checked={s.usePublicPage} onChange={(v) => set({ usePublicPage: v })} /></div></Block>
        <Block><div className="flex items-center justify-between"><FieldLabel>多廣告主廣告</FieldLabel><Toggle checked={s.multiAdvertiser} onChange={(v) => set({ multiAdvertiser: v })} /></div></Block>
        <Block><FieldLabel>網站事件追蹤</FieldLabel><Select options={["請選擇", "Pixel A", "Pixel B"]} value={s.websiteEvent || "請選擇"} onChange={(v) => set({ websiteEvent: v === "請選擇" ? "" : v })} /></Block>
      </>);
      default: return null;
    }
  }

  const cur = STEPS.find((x) => x.id === step);
  const fmtBudget = (bd) => s.cbo ? `${s.budgetType}：${s.campaignBudget || "1.00"} USD` : `單日預算：${bd.budget || "1.00"} USD`;
  const fmtSchedule = (bd) => bd.schedule === "自訂" ? `自訂（${bd.startDate}${bd.startTime ? " " + bd.startTime : ""}）` : "現在開始";
  const publish = () => { setPreview(false); setToast(`✅ 已發布（${m.ads} 則廣告），背景執行中`); setTimeout(() => setToast(""), 2800); };
  const previewRows = [];
  s.geo.forEach((geo) => s.target.forEach((tg, ti) => s.bid.forEach((bd, bi) => s.creative.forEach((cr, ci) => previewRows.push({ geo, tg, bd, cr, ti, bi, ci })))));
  const splitRows = [["地區組", m.R], ["定向包", m.T], ["出價和預算", m.B], ["創意組", m.C]];

  return (
    <div className="w-full" style={{ fontFamily: "'Noto Sans TC','Microsoft JhengHei',system-ui,sans-serif" }}>
      <div className="flex items-center justify-between px-5 py-3 rounded-t-xl" style={{ background: BRAND_DK }}>
        <div className="flex items-center gap-2 text-white"><Layers size={18} /><span className="font-semibold">快速建立廣告 — 三欄式建立工作區</span><span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "rgba(255,255,255,.15)" }}>互動 Demo</span></div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-white/70">iOS14+ {s.ios14 ? "開" : "關"}　CBO {s.cbo ? "開" : "關"}</span>
          <button onClick={() => { setS(init); setAct({ geo: 0, target: 0, bid: 0, creative: 0 }); setStep(2); }} className="flex items-center gap-1 text-white/80 text-sm hover:text-white"><RotateCcw size={14} />重設</button>
        </div>
      </div>

      <div className="grid border border-slate-200 rounded-b-xl overflow-hidden" style={{ gridTemplateColumns: "190px 1fr 300px", minHeight: 600, background: "#fff" }}>
        <div className="border-r border-slate-200 py-2" style={{ background: "#F8FAFC" }}>
          {["Campaign", "Ad Set", "Ad"].map((stage) => (
            <div key={stage}>
              <div className="px-4 pt-3 pb-1 text-[11px] font-bold tracking-wider uppercase text-slate-400">{stage}</div>
              {STEPS.filter((x) => x.stage === stage).map((x) => {
                const Icon = x.icon, active = step === x.id, count = x.module ? s[x.module].length : null;
                return (
                  <button key={x.id} onClick={() => setStep(x.id)} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm transition-colors" style={{ background: active ? "#EAF1F8" : "transparent", color: active ? BRAND : "#475569", borderLeft: active ? `3px solid ${BRAND}` : "3px solid transparent", fontWeight: active ? 600 : 400 }}>
                    <span className="flex items-center justify-center h-6 w-6 rounded-full text-[11px] shrink-0" style={{ background: active ? BRAND : "#E2E8F0", color: active ? "#fff" : "#94A3B8" }}>{x.id}</span>
                    <Icon size={15} className="shrink-0" /><span className="text-left leading-tight flex-1">{x.t}</span>
                    {count !== null && <span className="text-[11px] px-1.5 rounded-full" style={{ background: count > 1 ? SPLIT_BG : "#E2E8F0", color: count > 1 ? SPLIT : "#94A3B8" }}>{count}</span>}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        <div className="flex flex-col" style={{ maxHeight: 600 }}>
          <div className="px-6 pt-4 pb-3 border-b border-slate-100 flex items-center justify-between">
            <div><div className="text-[11px] font-semibold tracking-wider uppercase" style={{ color: SPLIT }}>{cur.stage}　·　步驟 {cur.id} / 9</div>
              <h2 className="text-lg font-bold text-slate-800 mt-0.5 flex items-center gap-2"><cur.icon size={18} style={{ color: BRAND }} />{cur.t}</h2></div>
            {cur.module && <span className="text-xs text-slate-400">批量操作 ∨　清空</span>}
          </div>
          <div className="px-6 py-5 overflow-y-auto flex-1">{renderStep()}</div>
          <div className="px-6 py-3 border-t border-slate-100 flex justify-between">
            <button disabled={step === 1} onClick={() => setStep(step - 1)} className="px-4 py-2 text-sm rounded-md border border-slate-300 text-slate-600 disabled:opacity-40">上一步</button>
            <button disabled={step === 9} onClick={() => setStep(step + 1)} className="px-4 py-2 text-sm rounded-md text-white flex items-center gap-1 disabled:opacity-40" style={{ background: BRAND }}>下一步 <ChevronRight size={15} /></button>
          </div>
        </div>

        <div className="border-l border-slate-200 p-4 flex flex-col" style={{ background: "#FAFBFD" }}>
          <div className="rounded-lg border border-slate-200 bg-white p-3 mb-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 font-semibold text-slate-700"><span className="inline-flex h-5 w-5 items-center justify-center rounded text-white text-[10px]" style={{ background: "#1877F2" }}>∞</span>Meta</div>
              <button className="text-xs" style={{ color: BRAND }}>編輯</button>
            </div>
            <div className="text-xs text-slate-500 mb-2">已選帳戶數量：1</div>
            <table className="w-full text-xs"><thead><tr className="text-slate-500 border-b border-slate-100"><th className="text-left font-medium py-1.5">屬性</th><th className="text-center font-medium">數量</th><th className="text-right font-medium">拆分規則</th></tr></thead>
              <tbody>{splitRows.map(([name, n]) => (<tr key={name} className="border-b border-slate-50"><td className="py-2 text-slate-700">{name}</td><td className="text-center font-bold" style={{ color: n > 1 ? SPLIT : "#475569" }}>{n}</td><td className="text-right text-slate-500">廣告組</td></tr>))}</tbody>
            </table>
          </div>
          <div className="flex-1" />
          <button onClick={() => { setToast(`✅ 建立任務已送出（${m.ads} 則廣告），背景執行中`); setTimeout(() => setToast(""), 2800); }} className="w-full py-2.5 rounded-md text-white text-sm font-semibold flex items-center justify-center gap-1.5 mb-2" style={{ background: BRAND }}><Send size={15} />確認發佈</button>
          <button onClick={() => setPreview(true)} className="w-full py-2 rounded-md text-sm border border-slate-300 text-slate-600 flex items-center justify-center gap-1.5"><Eye size={14} />預覽</button>
        </div>
      </div>

      <div className="flex items-start gap-1.5 mt-3 text-xs text-slate-400">
        <Info size={13} className="mt-0.5 shrink-0" />
        <span>試試在步驟 2 切換 CBO：開啟時預算／競價策略／投放時段／投放類型／花費限額出現在 Campaign 層，步驟 7 改顯示「廣告組花費限額」；關閉時相反。再切 iOS 14+，競價策略名稱與成效目標選項會跟著變。</span>
      </div>

      {preview && (
        <div className="fixed inset-0 z-40 overflow-auto" style={{ background: "#F4F6F9" }}>
          <div className="max-w-[1500px] mx-auto p-6">
            <div className="text-sm font-semibold text-slate-700 border-b border-slate-200 pb-2 mb-4">{s.adAccount}　936065231376017</div>
            <div className="grid gap-y-1.5 text-sm mb-4" style={{ gridTemplateColumns: "90px 1fr", maxWidth: 480 }}>
              <span className="text-slate-500">廣告帳戶</span><span className="text-slate-700">{s.adAccount}（936065231376017）</span>
              <span className="text-slate-500">時區</span><span className="text-slate-700">Asia/Taipei</span>
              <span className="text-slate-500">推廣應用</span><span className="text-slate-700">{s.appName || "金好運娛樂城"}</span>
            </div>
            <div className="flex items-center justify-between mb-2">
              <button className="rounded border border-slate-300 px-3 py-1.5 text-sm text-slate-400">批量操作 ∨</button>
              <div className="text-sm font-semibold text-slate-700">廣告系列 <span style={{ color: BRAND }}>1</span>　廣告組 <span style={{ color: BRAND }}>{m.adSets}</span>　廣告 <span style={{ color: OK }}>{m.ads}</span></div>
            </div>
            <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
              <table className="w-full text-sm">
                <thead><tr className="bg-slate-50 text-slate-500 text-left">
                  {["狀態", "廣告組", "所屬廣告系列", "操作", "地區", "出價與預算", "廣告"].map((h) => <th key={h} className="font-medium px-4 py-2.5 whitespace-nowrap">{h}</th>)}
                </tr></thead>
                <tbody>
                  {previewRows.slice(0, 200).map((r, i) => (
                    <tr key={i} className="border-t border-slate-100 align-top">
                      <td className="px-4 py-3"><Toggle checked={rowStatus[i] ?? true} onChange={() => setRowStatus((p) => ({ ...p, [i]: !(p[i] ?? true) }))} /></td>
                      <td className="px-4 py-3 text-slate-700">_{r.geo.name}_預覽
                        {(s.target.length > 1 || s.bid.length > 1 || s.creative.length > 1) && <div className="text-[11px] text-slate-400 mt-0.5">{[s.target.length > 1 && r.tg.name, s.bid.length > 1 && r.bd.name, s.creative.length > 1 && r.cr.name].filter(Boolean).join(" · ")}</div>}
                      </td>
                      <td className="px-4 py-3 text-slate-600">{s.campaignName || "IGS-02-金好運TW_"}</td>
                      <td className="px-4 py-3 whitespace-nowrap"><button style={{ color: BRAND }}>複製</button>　<button style={{ color: BRAND }}>刪除</button></td>
                      <td className="px-4 py-3 text-slate-600">{r.geo.target.length ? r.geo.target.join(", ") : "全部"}</td>
                      <td className="px-4 py-3 text-slate-600 whitespace-nowrap text-[13px] leading-relaxed">
                        成效目標：{r.bd.perfGoal}<br />{fmtBudget(r.bd)}<br />排期：{fmtSchedule(r.bd)}
                      </td>
                      <td className="px-4 py-3 text-slate-600 text-[13px]">廣告數：（{adsOf(r.cr)}）<div className="text-slate-400 mt-0.5 max-w-xs break-all">{s.adName}</div></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {previewRows.length > 200 && <div className="text-xs text-slate-400 mt-2">僅顯示前 200 列，共 {previewRows.length} 個廣告組。</div>}
            <div className="text-xs text-slate-400 mt-2">共 {m.adSets} 條　·　20條/頁</div>
            <div className="flex justify-center gap-3 mt-6 pb-4">
              <button onClick={() => setPreview(false)} className="rounded-md border border-slate-300 px-6 py-2 text-sm text-slate-600">返回</button>
              <button onClick={publish} className="rounded-md border border-slate-300 px-6 py-2 text-sm text-slate-700">發布並繼續創建</button>
              <button onClick={publish} className="rounded-md px-8 py-2 text-sm text-white font-semibold" style={{ background: BRAND }}>發布</button>
            </div>
          </div>
        </div>
      )}

      {toast && <div className="fixed bottom-6 left-1/2 -translate-x-1/2 px-5 py-3 rounded-lg text-white text-sm shadow-lg z-50" style={{ background: OK }}>{toast}</div>}
    </div>
  );
}
